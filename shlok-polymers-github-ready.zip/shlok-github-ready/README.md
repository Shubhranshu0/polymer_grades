# Shlok Polymers Website

Next.js application generated from the ZLM project and prepared for GitHub-based deployment.

## Important
- Do not commit `.env` files or secrets.
- Source PDFs/uploads, generated screenshots, old Git history, local SQLite database files, and ZLM runtime artifacts were intentionally excluded from this repository copy.
- The application dataset used by the website remains in `public/data/dataset.json`.

## Local development
1. Install Bun (or use the package manager appropriate to the project).
2. Install dependencies.
3. Run the development server.
4. Test the production build before deployment.

## Deployment
This repository is intended to be connected to a Git-based hosting service such as Render. Before first production deployment, have Codex audit the ZLM-specific configuration, Prisma/SQLite scaffolding, environment variables, and production start command.
